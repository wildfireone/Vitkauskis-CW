<?php
session_start();
session_destroy();
?>
Logged out. <a href="index.php">Go back </a>